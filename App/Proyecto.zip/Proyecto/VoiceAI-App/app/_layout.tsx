// app/_layout.tsx
import { useEffect, useState } from "react";
import { Stack } from "expo-router";
import { router } from "expo-router";
import { getToken } from "../services/auth";

export default function RootLayout() {
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    (async () => {
      const token = await getToken();
      if (token) {
        router.replace("/(main)");
      } else {
        router.replace("/(auth)/login");
      }
      setChecked(true);
    })();
  }, []);

  if (!checked) return null;

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(auth)/login" />
      <Stack.Screen name="(main)/index" />
    </Stack>
  );
}
