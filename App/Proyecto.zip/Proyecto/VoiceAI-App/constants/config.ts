// constants/config.ts
export const BASE_URL = "https://tu-vps.com"; // ← CAMBIAR

export const API_V1 = `${BASE_URL}/api/v1`;

export const ENDPOINTS = {
  // Auth — acepta JSON { codigo_registro }  (router.py: auth.router)
  login:     `${API_V1}/auth/login`,
  // NOTA: no existe /register en router.py — el registro lo hace el administrador

  // Voz — autenticación por X-Device-Id, NO JWT  (router.py: voz.router)
  voz:       `${API_V1}/voz`,
  vozStatus: `${API_V1}/voz/status`,   // GET /voz/status/{task_id}

  // Historial de interacciones  (router.py: historial.router)
  historial: `${API_V1}/historial`,

  // Progreso clínico  (router.py: progreso.router)
  progreso:  `${API_V1}/progreso`,
};

// Polling de la tarea de voz asíncrona
export const POLL_INTERVAL_MS = 2_000;   // Consultar cada 2 segundos
export const POLL_TIMEOUT_MS  = 60_000;  // Máximo 60 segundos total
