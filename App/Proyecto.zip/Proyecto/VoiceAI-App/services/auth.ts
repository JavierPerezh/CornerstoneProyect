// services/auth.ts
// ─────────────────────────────────────────────────────────────────────────────
// Según init.sql, la tabla `usuarios` NO tiene email ni password.
// El login es por `codigo_registro` (VARCHAR 6), único por usuario.
// El `dispositivo_id` también vive en `usuarios` — no hay tabla separada.
//
// Flujo real:
//   - La paciente recibe un código de 6 dígitos del sistema Cornerst
//   - Ese código se usa para autenticarse Y determina su dispositivo_id
// ─────────────────────────────────────────────────────────────────────────────
import * as SecureStore from "expo-secure-store";
import { ENDPOINTS } from "../constants/config";

const TOKEN_KEY      = "cornerst_jwt";
const UUID_KEY       = "cornerst_uuid";
const DEVICE_ID_KEY  = "cornerst_device_id";
const CODIGO_KEY     = "cornerst_codigo";

export interface AuthResponse {
  access_token: string;
  token_type: "bearer";
  usuario_uuid: string;
  dispositivo_id?: string; // El backend puede devolverlo para que la app lo use en /voz
}

// ── LOGIN por código de registro ──────────────────────────────────────────────
export async function login(codigo_registro: string): Promise<AuthResponse> {
  const res = await fetch(ENDPOINTS.login, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ codigo_registro }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.detail || "Código de registro inválido");
  }

  const data: AuthResponse = await res.json();
  await SecureStore.setItemAsync(TOKEN_KEY, data.access_token);
  await SecureStore.setItemAsync(UUID_KEY, data.usuario_uuid);
  await SecureStore.setItemAsync(CODIGO_KEY, codigo_registro);

  // Si el backend devuelve el dispositivo_id, guardarlo automáticamente
  if (data.dispositivo_id) {
    await SecureStore.setItemAsync(DEVICE_ID_KEY, data.dispositivo_id);
  }

  return data;
}

// ── DEVICE ID (usuarios.dispositivo_id) ───────────────────────────────────────
// El dispositivo_id puede venir del login o configurarse manualmente en Ajustes.
export async function setDeviceId(deviceId: string): Promise<void> {
  await SecureStore.setItemAsync(DEVICE_ID_KEY, deviceId);
}

export async function getDeviceId(): Promise<string | null> {
  return SecureStore.getItemAsync(DEVICE_ID_KEY);
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
export async function getToken(): Promise<string | null> {
  return SecureStore.getItemAsync(TOKEN_KEY);
}

export async function getCodigoRegistro(): Promise<string | null> {
  return SecureStore.getItemAsync(CODIGO_KEY);
}

export async function logout(): Promise<void> {
  await SecureStore.deleteItemAsync(TOKEN_KEY);
  await SecureStore.deleteItemAsync(UUID_KEY);
  // Mantener DEVICE_ID y CODIGO para no pedirlos de nuevo al re-login
}
